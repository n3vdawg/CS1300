# TYLER NEVELL

import turtle as x
def hw3():
    
    for t in range(4):
        x.right(90)
        x.forward(80)
        
        
    for s in range(1):
        x.left(120)
        x.forward(80)
        x.left(120)
        x.forward(80)
        
    x.penup()
    x.left(120)
    x.forward(180)
    x.right(90)
    x.forward(80)
    x.pendown()
    x.left(135)
    x.forward(30)
    x.right(90)
    x.forward(30)
    x.left(180)
    x.forward(30)
    x.right(45)
    x.forward(30)
    x.left(90)
    x.forward(30)
    x.left(180)
    x.forward(60)
    x.left(180)
    x.forward(30)
    x.right(90)
    x.forward(20)
    x.right(90)
    
    for c in range(120):
        x.forward(1)
        x.left(3)
    

    x.exitonclick()
    x.done()
hw3() 