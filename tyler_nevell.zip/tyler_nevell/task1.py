# TYLER NEVELL

def hw3():
    
    #Print every number in the numbers list
    print("Print every number in the numbers list\n")
    for x in [12, 10, 32, 3, 66, 17, 42, 99, 20]:
        print(x)
    print()

    #Print every number and its square from the numbers list
    print("Print every number and its square from the numbers list\n")
    for y in [12, 10, 32, 3, 66, 17, 42, 99, 20]:
        print(y, y**2)
        
hw3()       
